#pragma  once

class Vector3f
{
public:
		float x, y, z;
		Vector3f(){}
		Vector3f(float _x, float _y, float _z)
		{
				x = _x;
				y = _y;
				z = _z;
		}
};