#pragma once

#pragma comment(lib,"freeglut.lib")
#pragma comment(lib,"glew32.lib")