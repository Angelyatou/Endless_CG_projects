#include <stdio.h>
#include "EGL/egl.h"
#include "GLES2/gl2.h"

int main(int argc, char **argv)
{
    EGLint major, minor;
    EGLDisplay display = eglGetDisplay(0);

    eglInitialize(display, &major, &minor);
    printf("egl version: %d.%d\n", major, minor);
    return 0;
}