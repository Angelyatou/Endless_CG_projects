#include "win_platform.h"

static ATOM                 regClass;       /* Register class. */
static EglObj               egl;            /* to hold vdk information.*/
NativeDisplayType           display;
NativeWindowType            window;

/*******************************************************************************
 * Events.                                                                     *
 *******************************************************************************/
/*******************************************************************************
** Default keyboard map. *******************************************************
*/
static KeyMap keys[] =
{
    /* 00 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 01 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 02 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 03 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 04 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 05 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 06 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 07 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 08 */ { KEY_BACKSPACE,       KEY_UNKNOWN     },
    /* 09 */ { KEY_TAB,             KEY_UNKNOWN     },
    /* 0A */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 0B */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 0C */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 0D */ { KEY_ENTER,           KEY_UNKNOWN     },
    /* 0E */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 0F */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 10 */ { KEY_LSHIFT,          KEY_NUMLOCK     },
    /* 11 */ { KEY_LCTRL,           KEY_SCROLLLOCK  },
    /* 12 */ { KEY_LALT,            KEY_UNKNOWN     },
    /* 13 */ { KEY_BREAK,           KEY_UNKNOWN     },
    /* 14 */ { KEY_CAPSLOCK,        KEY_UNKNOWN     },
    /* 15 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 16 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 17 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 18 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 19 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 1A */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 1B */ { KEY_ESCAPE,          KEY_UNKNOWN     },
    /* 1C */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 1D */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 1E */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 1F */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 20 */ { KEY_SPACE,           KEY_LSHIFT      },
    /* 21 */ { KEY_PGUP,            KEY_RSHIFT      },
    /* 22 */ { KEY_PGDN,            KEY_LCTRL       },
    /* 23 */ { KEY_END,             KEY_RCTRL       },
    /* 24 */ { KEY_HOME,            KEY_LALT        },
    /* 25 */ { KEY_LEFT,            KEY_RALT        },
    /* 26 */ { KEY_UP,              KEY_UNKNOWN     },
    /* 27 */ { KEY_RIGHT,           KEY_UNKNOWN     },
    /* 28 */ { KEY_DOWN,            KEY_UNKNOWN     },
    /* 29 */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 2A */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 2B */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 2C */ { KEY_PRNTSCRN,        KEY_UNKNOWN     },
    /* 2D */ { KEY_INSERT,          KEY_UNKNOWN     },
    /* 2E */ { KEY_DELETE,          KEY_UNKNOWN     },
    /* 2F */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 30 */ { KEY_0,               KEY_UNKNOWN     },
    /* 31 */ { KEY_1,               KEY_UNKNOWN     },
    /* 32 */ { KEY_2,               KEY_UNKNOWN     },
    /* 33 */ { KEY_3,               KEY_UNKNOWN     },
    /* 34 */ { KEY_4,               KEY_UNKNOWN     },
    /* 35 */ { KEY_5,               KEY_UNKNOWN     },
    /* 36 */ { KEY_6,               KEY_UNKNOWN     },
    /* 37 */ { KEY_7,               KEY_UNKNOWN     },
    /* 38 */ { KEY_8,               KEY_UNKNOWN     },
    /* 39 */ { KEY_9,               KEY_UNKNOWN     },
    /* 3A */ { KEY_UNKNOWN,         KEY_SEMICOLON   },
    /* 3B */ { KEY_UNKNOWN,         KEY_EQUAL       },
    /* 3C */ { KEY_UNKNOWN,         KEY_COMMA       },
    /* 3D */ { KEY_UNKNOWN,         KEY_HYPHEN      },
    /* 3E */ { KEY_UNKNOWN,         KEY_PERIOD      },
    /* 3F */ { KEY_UNKNOWN,         KEY_SLASH       },
    /* 40 */ { KEY_UNKNOWN,         KEY_BACKQUOTE   },
    /* 41 */ { KEY_A,               KEY_UNKNOWN     },
    /* 42 */ { KEY_B,               KEY_UNKNOWN     },
    /* 43 */ { KEY_C,               KEY_UNKNOWN     },
    /* 44 */ { KEY_D,               KEY_UNKNOWN     },
    /* 45 */ { KEY_E,               KEY_UNKNOWN     },
    /* 46 */ { KEY_F,               KEY_UNKNOWN     },
    /* 47 */ { KEY_G,               KEY_UNKNOWN     },
    /* 48 */ { KEY_H,               KEY_UNKNOWN     },
    /* 49 */ { KEY_I,               KEY_UNKNOWN     },
    /* 4A */ { KEY_J,               KEY_UNKNOWN     },
    /* 4B */ { KEY_K,               KEY_UNKNOWN     },
    /* 4C */ { KEY_L,               KEY_UNKNOWN     },
    /* 4D */ { KEY_M,               KEY_UNKNOWN     },
    /* 4E */ { KEY_N,               KEY_UNKNOWN     },
    /* 4F */ { KEY_O,               KEY_UNKNOWN     },
    /* 50 */ { KEY_P,               KEY_UNKNOWN     },
    /* 51 */ { KEY_Q,               KEY_UNKNOWN     },
    /* 52 */ { KEY_R,               KEY_UNKNOWN     },
    /* 53 */ { KEY_S,               KEY_UNKNOWN     },
    /* 54 */ { KEY_T,               KEY_UNKNOWN     },
    /* 55 */ { KEY_U,               KEY_UNKNOWN     },
    /* 56 */ { KEY_V,               KEY_UNKNOWN     },
    /* 57 */ { KEY_W,               KEY_UNKNOWN     },
    /* 58 */ { KEY_X,               KEY_UNKNOWN     },
    /* 59 */ { KEY_Y,               KEY_UNKNOWN     },
    /* 5A */ { KEY_Z,               KEY_UNKNOWN     },
    /* 5B */ { KEY_LWINDOW,         KEY_LBRACKET    },
    /* 5C */ { KEY_RWINDOW,         KEY_BACKSLASH   },
    /* 5D */ { KEY_MENU,            KEY_RBRACKET    },
    /* 5E */ { KEY_UNKNOWN,         KEY_SINGLEQUOTE },
    /* 5F */ { KEY_SLEEP,           KEY_UNKNOWN     },
    /* 60 */ { KEY_PAD_0,           KEY_UNKNOWN     },
    /* 61 */ { KEY_PAD_1,           KEY_UNKNOWN     },
    /* 62 */ { KEY_PAD_2,           KEY_UNKNOWN     },
    /* 63 */ { KEY_PAD_3,           KEY_UNKNOWN     },
    /* 64 */ { KEY_PAD_4,           KEY_UNKNOWN     },
    /* 65 */ { KEY_PAD_5,           KEY_UNKNOWN     },
    /* 66 */ { KEY_PAD_6,           KEY_UNKNOWN     },
    /* 67 */ { KEY_PAD_7,           KEY_UNKNOWN     },
    /* 68 */ { KEY_PAD_8,           KEY_UNKNOWN     },
    /* 69 */ { KEY_PAD_9,           KEY_UNKNOWN     },
    /* 6A */ { KEY_PAD_ASTERISK,    KEY_UNKNOWN     },
    /* 6B */ { KEY_PAD_PLUS,        KEY_UNKNOWN     },
    /* 6C */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 6D */ { KEY_PAD_HYPHEN,      KEY_UNKNOWN     },
    /* 6E */ { KEY_PAD_PERIOD,      KEY_UNKNOWN     },
    /* 6F */ { KEY_PAD_SLASH,       KEY_UNKNOWN     },
    /* 70 */ { KEY_F1,              KEY_UNKNOWN     },
    /* 71 */ { KEY_F2,              KEY_UNKNOWN     },
    /* 72 */ { KEY_F3,              KEY_UNKNOWN     },
    /* 73 */ { KEY_F4,              KEY_UNKNOWN     },
    /* 74 */ { KEY_F5,              KEY_UNKNOWN     },
    /* 75 */ { KEY_F6,              KEY_UNKNOWN     },
    /* 76 */ { KEY_F7,              KEY_UNKNOWN     },
    /* 77 */ { KEY_F8,              KEY_UNKNOWN     },
    /* 78 */ { KEY_F9,              KEY_UNKNOWN     },
    /* 79 */ { KEY_F10,             KEY_UNKNOWN     },
    /* 7A */ { KEY_F11,             KEY_UNKNOWN     },
    /* 7B */ { KEY_F12,             KEY_UNKNOWN     },
    /* 7C */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 7D */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 7E */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
    /* 7F */ { KEY_UNKNOWN,         KEY_UNKNOWN     },
};

STATUS WinGetEvent(NativeWindowType Window, InputEvent *Event)
{
    /* Message. */
    MSG msg;

    /* Translated scancode. */
    Keys scancode;

    /* Test for valid Window and Event pointers. */
    if ((Window == NULL) || (Event == NULL))
    {
        return eglSTATUS_INVALID_ARGUMENT;
    }

    /* Loop while there are messages in the queue for the window. */
    while (PeekMessage(&msg, (NativeWindowType)Window, 0, 0, PM_REMOVE))
    {
        switch (msg.message)
        {
        case WM_KEYDOWN:
        case WM_KEYUP:
            /* Keyboard event. */
            Event->type = EVENT_KEYBOARD;

            /* Translate the scancode. */
            scancode = (msg.wParam & 0x80)
                     ? keys[msg.wParam & 0x7F].extended
                     : keys[msg.wParam & 0x7F].normal;

            /* Set scancode. */
            Event->data.keyboard.scancode = scancode;

            /* Set ASCII key. */
            Event->data.keyboard.key = (  (scancode < KEY_SPACE)
                                       || (scancode >= KEY_F1)
                                       )
                                       ? 0
                                       : (char) scancode;

            /* Set up or down flag. */
            Event->data.keyboard.pressed = (msg.message == WM_KEYDOWN);

            /* Valid event. */
            return eglSTATUS_OK;

        case WM_CLOSE:
        case WM_DESTROY:
        case WM_QUIT:
            /* Application should close. */
            Event->type = EVENT_CLOSE;

            /* Valid event. */
            return eglSTATUS_OK;

        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_MBUTTONDOWN:
        case WM_MBUTTONUP:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:
            /* Button event. */
            Event->type = EVENT_BUTTON;

            /* Set button states. */
            Event->data.button.left   = (msg.wParam & MK_LBUTTON) ? 1 : 0;
            Event->data.button.middle = (msg.wParam & MK_MBUTTON) ? 1 : 0;
            Event->data.button.right  = (msg.wParam & MK_RBUTTON) ? 1 : 0;
            Event->data.button.x      = LOWORD(msg.lParam);
            Event->data.button.y      = HIWORD(msg.lParam);

            /* Valid event. */
            return eglSTATUS_OK;

        case WM_MOUSEMOVE:
            /* Pointer event.*/
            Event->type = EVENT_POINTER;

            /* Set pointer location. */
            Event->data.pointer.x = LOWORD(msg.lParam);
            Event->data.pointer.y = HIWORD(msg.lParam);

            /* Valid event. */
            return eglSTATUS_OK;

        default:
            /* Translate and dispatch message. */
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            break;
        }
    }

    /* Test if the window is still valid. */
    if (!IsWindow((NativeWindowType)Window))
    {
        /* Application should close. */
        Event->type = EVENT_CLOSE;

        /* Valid event. */
        return eglSTATUS_OK;
    }

    /* No event pending. */
    return eglSTATUS_NOT_FOUND;
}

STATUS WinGetNativeDisplay(OUT NativeDisplayType * Display, IN void* Context)
{
    int     bpp     = 0;
    STATUS  status  = eglSTATUS_OK;

    do
    {
        /* Create the device context. */
        *Display = CreateDC(TEXT("DISPLAY"), NULL, NULL, NULL);

        if (*Display == NULL)
        {
            /* Break if the device context could not be created. */
            status = eglSTATUS_OUT_OF_RESOURCES;
            break;
        }

        /* Get the display size and color depth. */
        bpp    = GetDeviceCaps(*Display, BITSPIXEL);
        if((bpp != 16) && (bpp != 32))
        {
            status = eglSTATUS_NOT_SUPPORTED;
            break;
        }

        /* Return the pointer to the display data structure. */
        return status;
    }
    while (0);

    /* Roll back on error. */
    if (*Display != NULL)
    {
        DeleteDC(*Display);
    }

    /* Error. */
    return status;
}

LRESULT CALLBACK
_WindowProc(
    HWND Window,
    UINT Message,
    WPARAM ParameterW,
    LPARAM ParameterL
    )
{
    /* We do nothing here - just return the default method for the message. */
    return DefWindowProc(Window, Message, ParameterW, ParameterL);
}

STATUS WinCreateWindowClass(char *className)
{
    WNDCLASS wndClass;
    STATUS status = eglSTATUS_OK;

    /* Initialize the WNDCLASS structure. */
    ZeroMemory(&wndClass, sizeof(wndClass));
    wndClass.lpfnWndProc   = _WindowProc;
    wndClass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wndClass.hCursor       = LoadCursor(NULL, IDC_CROSS);
    wndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    wndClass.lpszClassName = TEXT(className);

    /* Register the window class. */
    regClass = RegisterClass(&wndClass);

    if (regClass == 0)
    {
        /* RegisterClass failed. */
        status = eglSTATUS_NOT_SUPPORTED;
        return status;
    }

    return eglSTATUS_OK;
}

STATUS WinCreateNativeWindow(IN char *className,
                             IN char *wndName,
                             IN NativeDisplayType Display,
                             IN int X,
                             IN int Y,
                             IN int Width,
                             IN int Height,
                             OUT NativeWindowType * Window)
{
    int     displayWidth;
    int     displayHeight;
    STATUS  status = eglSTATUS_OK;

    /* Test if we have a valid display data structure pointer. */
    if (Display == NULL)
    {
        status = eglSTATUS_INVALID_ARGUMENT;
        return status;
    }

    displayWidth = GetDeviceCaps(Display, HORZRES);
    displayHeight = GetDeviceCaps(Display, VERTRES);

    /* Test for zero width. */
    if (Width == 0)
    {
        /* Use display width instead. */
        Width = displayWidth;
    }
    else
    {
        /* Clamp width to display width. */
        Width = min(Width, displayWidth);
    }

    /* Test for zero height. */
    if (Height == 0)
    {
        /* Use display height instead. */
        Height = displayHeight;
    }
    else
    {
        /* Clamp height to display height. */
        Height = min(Height, displayHeight);
    }

    /* Test for auto-center X coordinate. */
    if (X == -1)
    {
        /* Center the window horizontally. */
        X = (displayWidth - Width) / 2;
    }

    /* Test for auto-center Y coordinate. */
    if (Y == -1)
    {
        /* Center the window vertically. */
        Y = (displayHeight - Height) / 2;
    }

    /* Clamp coordinates to display. */
    if (X < 0) X = 0;
    if (Y < 0) Y = 0;
    if (X + Width  > displayWidth)  Width  = displayWidth  - X;
    if (Y + Height > displayHeight) Height = displayHeight - Y;

    do
    {
        /* Window rectangle. */
        RECT rect;

        /* Window style. */
        UINT style = WS_POPUPWINDOW | WS_CAPTION;
        UINT extra = 0;

        SystemParametersInfo(SPI_GETWORKAREA, 0, &rect, FALSE);
        if (Y + Height > rect.bottom)
        {
            extra = WS_EX_TOPMOST;
        }

        /* Set the window rectangle. */
        rect.left   = X;
        rect.top    = Y;
        rect.right  = X + Width;
        rect.bottom = Y + Height;

        /* Adjust the window rectangle for the style. */
        AdjustWindowRectEx(&rect, style, FALSE, extra);

        /* Create the window. */
        *Window = CreateWindowEx(extra,
                                 TEXT(className),
                                 TEXT(wndName),
                                 style,
                                 rect.left,
                                 rect.top,
                                 rect.right - rect.left,
                                 rect.bottom - rect.top,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL);

        if (*Window == NULL)
        {
            /* Break on bad window. */
            break;
        }

        /* Return pointer to the window data structure. */
        return status;
    }
    while (0);

    if(*Window != NULL)
    {
        DestroyWindow(*Window);
    }

    /* Error. */
    status = eglSTATUS_OUT_OF_RESOURCES;
    return status;
}

int WinSetupNativeWindow(int X, int Y, int Width, int Height)
{
    STATUS status = eglSTATUS_OK;

    status = WinCreateWindowClass("playerClass");
    if (status != eglSTATUS_OK)
    {
        return 0;
    }

    WinGetNativeDisplay(&display, 0);
    if (display == NULL)
    {
        return 0;
    }

    /* Create the window. */
    WinCreateNativeWindow("playerClass",
                          "playerWnd",
                          NativeDisplayType(display),
                          X,
                          Y,
                          Width,
                          Height,
                          &window);

    /* Test for error. */
    if (window == 0)
    {
        return 0;
    }

    /* Success. */
    return 1;
}

STATUS WinHideWindow(IN NativeWindowType Window)
{
    HWND window;

    if (Window == NULL)
    {
        return eglSTATUS_INVALID_ARGUMENT;
    }

    /* Get the window handle. */
    if (IsWindow((HWND) Window))
    {
        window = (HWND) Window;
    }
    else
    {
        return eglSTATUS_INVALID_OBJECT;
    }

    /* Hide the window. */
    ShowWindow(window, SW_HIDE);
    return eglSTATUS_OK;
}

STATUS WinDestroyWindow(NativeWindowType Window)
{
    /* Only process if we have a valid pointer */
    if (Window != NULL)
    {
        /* Destroy the window. */
        DestroyWindow(Window);
    }
    return eglSTATUS_OK;
}

STATUS WinDestroyDisplay(IN NativeDisplayType Display)
{
    /* Only process if we have a valid pointer. */
    if (Display != NULL)
    {
        /* Delete the device context. */
        DeleteDC(Display);
    }
    return eglSTATUS_OK;
}