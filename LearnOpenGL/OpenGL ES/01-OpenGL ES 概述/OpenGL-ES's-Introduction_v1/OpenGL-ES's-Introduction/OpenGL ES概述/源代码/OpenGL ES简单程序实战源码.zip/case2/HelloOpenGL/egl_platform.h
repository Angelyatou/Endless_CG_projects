#ifndef _EGL_PLATFORM_H
#define _EGL_PLATFORM_H

#if defined(_WIN32)
#include <windows.h>
#include <strsafe.h>

/* Win32 platforms. */
typedef HDC             NativeDisplayType;
typedef HWND            NativeWindowType;
typedef HBITMAP         NativePixmapType;

typedef struct __BITFIELDINFO
{
    BITMAPINFO    bmi;
    RGBQUAD       bmiColors[2];
} BITFIELDINFO;
#endif

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define EGL_CONFIG_RGB565_D16       ((const EGLint *) 1)
#define EGL_CONFIG_RGB565_D24       ((const EGLint *) 3)
#define EGL_CONFIG_RGB888_D16       ((const EGLint *) 5)
#define EGL_CONFIG_RGB888_D24       ((const EGLint *) 7)
#define EGL_CONFIG_RGB565_D16_AA    ((const EGLint *) 9)
#define EGL_CONFIG_RGB565_D24_AA    ((const EGLint *) 11)
#define EGL_CONFIG_RGB888_D16_AA    ((const EGLint *) 13)
#define EGL_CONFIG_RGB888_D24_AA    ((const EGLint *) 15)
#define EGL_CONFIG_RGB565           ((const EGLint *) 17)
#define EGL_CONFIG_RGB888           ((const EGLint *) 19)
#define EGL_CONFIG_RGB565_AA        ((const EGLint *) 21)
#define EGL_CONFIG_RGB888_AA        ((const EGLint *) 23)

/* OpenVG Configurations. */
#define EGL_CONFIG_RGB565_VG        ((const EGLint *) 500)
#define EGL_CONFIG_RGB888_VG        ((const EGLint *) 501)

#define EGL_CONTEXT_ES11            ((const EGLint *) 0)
#define EGL_CONTEXT_ES20            ((const EGLint *) 2)


typedef enum _STATUS
{
    eglSTATUS_OK                    =   0,
    eglSTATUS_FALSE                 =   0,
    eglSTATUS_TRUE                  =   1,
    eglSTATUS_NO_MORE_DATA          =   2,
    eglSTATUS_CACHED                =   3,
    eglSTATUS_MIPMAP_TOO_LARGE      =   4,
    eglSTATUS_NAME_NOT_FOUND        =   5,
    eglSTATUS_NOT_OUR_INTERRUPT     =   6,
    eglSTATUS_MISMATCH              =   7,
    eglSTATUS_MIPMAP_TOO_SMALL      =   8,
    eglSTATUS_LARGER                =   9,
    eglSTATUS_SMALLER               =   10,
    eglSTATUS_CHIP_NOT_READY        =   11,
    eglSTATUS_NEED_CONVERSION       =   12,
    eglSTATUS_SKIP                  =   13,
    eglSTATUS_DATA_TOO_LARGE        =   14,
    eglSTATUS_INVALID_CONFIG        =   15,
    eglSTATUS_CHANGED               =   16,
    eglSTATUS_NOT_SUPPORT_DITHER    =   17,
    eglSTATUS_EXECUTED              =   18,
    eglSTATUS_TERMINATE             =   19,

    eglSTATUS_INVALID_ARGUMENT      =   -1,
    eglSTATUS_INVALID_OBJECT        =   -2,
    eglSTATUS_OUT_OF_MEMORY         =   -3,
    eglSTATUS_MEMORY_LOCKED         =   -4,
    eglSTATUS_MEMORY_UNLOCKED       =   -5,
    eglSTATUS_HEAP_CORRUPTED        =   -6,
    eglSTATUS_GENERIC_IO            =   -7,
    eglSTATUS_INVALID_ADDRESS       =   -8,
    eglSTATUS_CONTEXT_LOSSED        =   -9,
    eglSTATUS_TOO_COMPLEX           =   -10,
    eglSTATUS_BUFFER_TOO_SMALL      =   -11,
    eglSTATUS_INTERFACE_ERROR       =   -12,
    eglSTATUS_NOT_SUPPORTED         =   -13,
    eglSTATUS_MORE_DATA             =   -14,
    eglSTATUS_TIMEOUT               =   -15,
    eglSTATUS_OUT_OF_RESOURCES      =   -16,
    eglSTATUS_INVALID_DATA          =   -17,
    eglSTATUS_INVALID_MIPMAP        =   -18,
    eglSTATUS_NOT_FOUND             =   -19,
    eglSTATUS_NOT_ALIGNED           =   -20,
    eglSTATUS_INVALID_REQUEST       =   -21,
    eglSTATUS_GPU_NOT_RESPONDING    =   -22,
    eglSTATUS_TIMER_OVERFLOW        =   -23,
    eglSTATUS_VERSION_MISMATCH      =   -24,
    eglSTATUS_LOCKED                =   -25,
    eglSTATUS_INTERRUPTED           =   -26,
    eglSTATUS_DEVICE                =   -27,
    eglSTATUS_NOT_MULTI_PIPE_ALIGNED =   -28,

    /* Linker errors. */
    eglSTATUS_GLOBAL_TYPE_MISMATCH  =   -1000,
    eglSTATUS_TOO_MANY_ATTRIBUTES   =   -1001,
    eglSTATUS_TOO_MANY_UNIFORMS     =   -1002,
    eglSTATUS_TOO_MANY_VARYINGS     =   -1003,
    eglSTATUS_UNDECLARED_VARYING    =   -1004,
    eglSTATUS_VARYING_TYPE_MISMATCH =   -1005,
    eglSTATUS_MISSING_MAIN          =   -1006,
    eglSTATUS_NAME_MISMATCH         =   -1007,
    eglSTATUS_INVALID_INDEX         =   -1008,
    eglSTATUS_UNIFORM_TYPE_MISMATCH =   -1009,

    /* Compiler errors. */
    eglSTATUS_COMPILER_FE_PREPROCESSOR_ERROR = -2000,
    eglSTATUS_COMPILER_FE_PARSER_ERROR = -2001,
} STATUS;

/* Scancodes for keyboard. */
typedef enum _Keys
{
    KEY_UNKNOWN = -1,
    
    KEY_BACKSPACE = 0x08,
    KEY_TAB,
    KEY_ENTER = 0x0D,
    KEY_ESCAPE = 0x1B,
    
    KEY_SPACE = 0x20,
    KEY_SINGLEQUOTE = 0x27,
    KEY_PAD_ASTERISK = 0x2A,
    KEY_COMMA = 0x2C,
    KEY_HYPHEN,
    KEY_PERIOD,
    KEY_SLASH,
    KEY_0,
    KEY_1,
    KEY_2,
    KEY_3,
    KEY_4,
    KEY_5,
    KEY_6,
    KEY_7,
    KEY_8,
    KEY_9,
    KEY_SEMICOLON = 0x3B,
    KEY_EQUAL = 0x3D,
    KEY_A = 0x41,
    KEY_B,
    KEY_C,          
    KEY_D,
    KEY_E,
    KEY_F,
    KEY_G,
    KEY_H,
    KEY_I,
    KEY_J,
    KEY_K,
    KEY_L,
    KEY_M,
    KEY_N,
    KEY_O,
    KEY_P,
    KEY_Q,
    KEY_R,
    KEY_S,
    KEY_T,
    KEY_U,
    KEY_V,
    KEY_W,
    KEY_X,
    KEY_Y,
    KEY_Z,
    KEY_LBRACKET,
    KEY_BACKSLASH,
    KEY_RBRACKET,
    KEY_BACKQUOTE = 0x60,

    KEY_F1 = 0x80,
    KEY_F2,
    KEY_F3,
    KEY_F4,
    KEY_F5,
    KEY_F6,
    KEY_F7,
    KEY_F8,
    KEY_F9,
    KEY_F10,
    KEY_F11,
    KEY_F12,

    KEY_LCTRL,
    KEY_RCTRL,
    KEY_LSHIFT,     
    KEY_RSHIFT,     
    KEY_LALT,
    KEY_RALT,
    KEY_CAPSLOCK,   
    KEY_NUMLOCK,            
    KEY_SCROLLLOCK, 
    KEY_PAD_0,              
    KEY_PAD_1,      
    KEY_PAD_2,          
    KEY_PAD_3,
    KEY_PAD_4,          
    KEY_PAD_5,
    KEY_PAD_6,              
    KEY_PAD_7,          
    KEY_PAD_8,
    KEY_PAD_9,              
    KEY_PAD_HYPHEN,  
    KEY_PAD_PLUS,
    KEY_PAD_SLASH,
    KEY_PAD_PERIOD, 
    KEY_PAD_ENTER,
    KEY_SYSRQ,
    KEY_PRNTSCRN,   
    KEY_BREAK,
    KEY_UP,             
    KEY_LEFT,
    KEY_RIGHT,
    KEY_DOWN,       
    KEY_HOME,       
    KEY_END,        
    KEY_PGUP,
    KEY_PGDN,           
    KEY_INSERT,
    KEY_DELETE,
    KEY_LWINDOW,    
    KEY_RWINDOW,    
    KEY_MENU,           
    KEY_POWER,
    KEY_SLEEP,
    KEY_WAKE
} Keys;

typedef enum _EventType
{
    /* Keyboard event. */
    EVENT_KEYBOARD,

    /* Mouse move event. */
    EVENT_POINTER,

    /* Mouse button event. */
    EVENT_BUTTON,

    /* Application close event. */
    EVENT_CLOSE,

    /* Application window has been updated. */
    EVENT_WINDOW_UPDATE
} EventType;

/* Event structure. */
typedef struct _InputEvent
{
    /* Event type. */
    EventType type;

    /* Event data union. */
    union _InputEventData
    {
        /* Event data for keyboard. */
        struct _vdkKeyboard
        {
            /* Scancode. */
            Keys    scancode;

            /* ASCII characte of the key pressed. */
            char    key;

            /* Flag whether the key was pressed (1) or released (0). */
            char    pressed;
        }
        keyboard;
        
        /* Event data for pointer. */
        struct _vdkPointer
        {
            /* Current pointer coordinate. */
            int        x;
            int        y;
        }
        pointer;
        
        /* Event data for mouse buttons. */
        struct _vdkButton
        {
            /* Left button state. */
            int        left;

            /* Middle button state. */
            int        middle;

            /* Right button state. */
            int        right;

            /* Current pointer coordinate. */
            int        x;
            int        y;
        }
        button;
    }
    data;
} InputEvent;

/* EGL prototypes. */
typedef EGLDisplay (EGLAPIENTRY * EGL_GET_DISPLAY)(
    EGLNativeDisplayType display_id
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_INITIALIZE)(
    EGLDisplay dpy,
    EGLint *major,
    EGLint *minor
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_TERMINATE)(
    EGLDisplay dpy
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_RELEASE_THREAD)(
    void
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_CHOOSE_CONFIG)(
    EGLDisplay dpy,
    const EGLint *attrib_list,
    EGLConfig *configs,
    EGLint config_size,
    EGLint *num_config
    );

typedef EGLSurface (EGLAPIENTRY * EGL_CREATE_WINDOW_SURFACE)(
    EGLDisplay dpy,
    EGLConfig config,
    EGLNativeWindowType win,
    const EGLint *attrib_list
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_DESTROY_SURFACE)(
    EGLDisplay dpy,
    EGLSurface surface
    );

typedef EGLContext (EGLAPIENTRY * EGL_CREATE_CONTEXT)(
    EGLDisplay dpy,
    EGLConfig config,
    EGLContext share_context,
    const EGLint *attrib_list
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_DESTROY_CONTEXT)(
    EGLDisplay dpy,
    EGLContext ctx
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_MAKE_CURRENT)(
    EGLDisplay dpy,
    EGLSurface draw,
    EGLSurface read,
    EGLContext ctx
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_SWAP_BUFFERS)(
    EGLDisplay dpy,
    EGLSurface surface
    );

typedef void (* EGL_PROC)(void);

typedef EGL_PROC (EGLAPIENTRY * EGL_GET_PROC_ADDRESS)(
    const char *procname
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_BIND_API)(
    EGLenum api
    );

typedef EGLBoolean (EGLAPIENTRY * EGL_SWAP_INTERVAL)(
    EGLDisplay dpy,
    EGLint interval
    );

/* EVENT_EGL structure defining the stuff required for EGL support. */
typedef struct _EglObj
{
    NativeDisplayType           display;
    NativeWindowType            window;

    /* EGL version. */
    EGLint                      eglMajor;
    EGLint                      eglMinor;

    /* EGL pointers. */
    EGLDisplay                  eglDisplay;
    EGLConfig                   eglConfig;
    EGLSurface                  eglSurface;
    EGLContext                  eglContext;

    /* EGL function pointers. */
    EGL_GET_DISPLAY             eglGetDisplay;
    EGL_INITIALIZE              eglInitialize;
    EGL_TERMINATE               eglTerminate;
    EGL_RELEASE_THREAD          eglReleaseThread;
    EGL_CHOOSE_CONFIG           eglChooseConfig;
    EGL_CREATE_WINDOW_SURFACE   eglCreateWindowSurface;
    EGL_DESTROY_SURFACE         eglDestroySurface;
    EGL_CREATE_CONTEXT          eglCreateContext;
    EGL_DESTROY_CONTEXT         eglDestroyContext;
    EGL_MAKE_CURRENT            eglMakeCurrent;
    EGL_SWAP_BUFFERS            eglSwapBuffers;
    EGL_GET_PROC_ADDRESS        eglGetProcAddress;
    EGL_BIND_API                eglBindAPI;
    EGL_SWAP_INTERVAL           eglSwapInterval;
} EglObj;

EGLint SwapEGL(EglObj *pEgl);
EGLint SetupEGL(EGLint X,
                EGLint Y,
                EGLint Width,
                EGLint Height,
                const EGLint * ConfigurationAttributes,
                const EGLint * SurfaceAttributes,
                const EGLint * ContextAttributes,
                EglObj *pEgl);
void FinishEGL(EglObj *pEgl);
EGLint GetEvent(NativeWindowType Window, InputEvent * Event);

#endif /* _EGL_PLATFORM_H */