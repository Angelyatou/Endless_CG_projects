#ifndef _WIN_PLATFORM_H
#define _WIN_PLATFORM_H

#include "egl_platform.h"

/* Structure that defined keyboard mapping. */
typedef struct _KeyMap
{
    /* Normal key. */
    Keys normal;

    /* Extended key. */
    Keys extended;
} KeyMap;

STATUS  WinCreateNativeWindow(IN char *className,
                              IN char *wndName,
                              IN NativeDisplayType Display,
                              IN int X,
                              IN int Y,
                              IN int Width,
                              IN int Height,
                              OUT NativeWindowType * Window);
STATUS  WinGetNativeDisplay(OUT NativeDisplayType * Display, IN void* Context);
STATUS  WinCreateWindowClass(char *className);
int     WinSetupNativeWindow(int X, int Y, int Width, int Height);
STATUS  WinHideWindow(IN NativeWindowType Window);
STATUS  WinDestroyWindow(NativeWindowType Window);
STATUS  WinDestroyDisplay(IN NativeDisplayType Display);
STATUS  WinGetEvent(NativeWindowType Window, InputEvent *Event);

#endif